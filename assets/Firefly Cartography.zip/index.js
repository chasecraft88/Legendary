import React from 'react';
import ReactDOM from 'react-dom';
import { Cartography } from './Cartography';
import { useCities } from './useCities';

const App = () => {
  const data = useCities();
  return <Cartography data={data}/>
}

ReactDOM.render(<App />, document.getElementById('root'));
